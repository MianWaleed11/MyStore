// import { ILoginData } from "./login.interface";
export interface IuserState {
    // users: ILoginData[];
    isLoading: boolean;
  }