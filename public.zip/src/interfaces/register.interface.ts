export interface ILoginData {
  firstname: string;
  lastname: string;
  email: string;
  password: string;
}