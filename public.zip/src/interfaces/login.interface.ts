export type LogInInterface = {
  email: string;
  password: string;
};
